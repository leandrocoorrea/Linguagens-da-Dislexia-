Jogo da forca em javascript
