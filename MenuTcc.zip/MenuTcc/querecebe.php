<?php include_once"confg.php";?>
<html>
<body>
<?php
$nome = $_POST["nome"];
$sobrenome = $_POST["sobrenome"];
$estado = $_POST["estado"];
$cidade = $_POST["cidade"];
$email = $_POST["email"];
$comentario = $_POST["comentario"];
$conn = mysqli_connect($servidor,$dbusuario,$dbsenha,$dbname);

mysqli_select_db($conn,'$dbname');
$sql = "INSERT INTO tbformulario(nome,sobrenome,estado,cidade,email,comentario) VALUES ('$nome','$sobrenome', '$estado', '$cidade', '$email', '$comentario')";
 if (mysqli_query($conn, $sql)) {
	 echo "<script>alert(' Mensagem enviada!'); window.location = 'quemsomos.html';</script>";
	 
 }else{
		echo "Aconteceu um erro" . $sql . "<br>" . mysqli_error($conn);
 }
 mysqli_close($conn);
 
?>
</body>
</html>